使用 FSDP+HuggingFace 添加新模型
========================================

本文档重点介绍如何使用 HuggingFace Transformers 库与 PyTorch FSDP（Fully Sharded Data Parallel，全分片数据并行）  
来训练和生成模型。它支持 HuggingFace 中实现的任意模型，只要兼容 PyTorch 即可。  
作为示例，本节将提供一个逐步的操作流程，展示如何按照 OpenVLA 模式将一个新的 HuggingFace 模型集成到 RLinf 中。  

前置条件
-------------

* 熟悉 **HuggingFace Transformers 库**  
* 理解 **RLinf** 框架架构  
* 掌握 **PyTorch** 与分布式训练知识  

逐步实现
---------------------------

1. 模型注册
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

现在推荐通过注册模型 builder 的方式接入 RLinf。对于“其他仓库依赖 RLinf”这种场景，这也是最推荐的接入方式。

.. code-block:: python

  from rlinf.models import register_model

  def build_my_model(cfg, torch_dtype):
      from your_package.your_model_action_model import (
          YourModelForRLActionPrediction,
      )

      return YourModelForRLActionPrediction.from_pretrained(
          cfg.model_path,
          torch_dtype=torch_dtype,
          hidden_size=cfg.hidden_size,
          unnorm_key=cfg.unnorm_key,
          action_dim=cfg.action_token_len,
          attn_implementation=cfg.attn_implementation,
          low_cpu_mem_usage=cfg.low_cpu_mem_usage,
          trust_remote_code=cfg.trust_remote_code,
      )

  register_model("your_model_type", build_my_model, category="embodied")

这一次注册会同时完成两件事：

- 让 ``model_type`` 通过 RLinf 的配置校验
- 让 ``rlinf.models.get_model(cfg)`` 能正确构建你的模型

作为依赖库使用时的分布式注册（``RLINF_EXT_MODULE``）
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

当 RLinf 以第三方依赖形式集成到你的工程里、并由 **Ray** 拉起分布式 Worker 时，
仅在主进程（driver）里执行 ``register_model(...)`` 等注册代码，**不会** 自动同步到
各个 Worker 进程：Worker 是独立的 Python 进程，不会重复执行你在入口脚本里的注册逻辑。
因此，在 rollout、训练等实际跑在 Worker 上的路径里，模型可能仍未注册，导致构建或
查找失败。

为此，请通过环境变量 ``RLINF_EXT_MODULE`` 指定一个 **扩展模块** 的 import 路径。
RLinf 在 **每个 Worker 初始化时** 会自动 ``import`` 该模块，并在存在时调用其
``register()``，从而在 Worker 侧完成与主进程一致的模型（或其它扩展）注册，无需改
RLinf 源码。

扩展模块需实现 ``register()``，在其中调用 ``register_model`` 等逻辑。环境变量写法与
说明见 ``rlinf/scheduler/cluster/cluster.py`` 中 ``ClusterEnvVar.EXT_MODULE`` 的文档字符串，
例如：

.. code-block:: bash

   export RLINF_EXT_MODULE=rlinf_ext
   # 或使用完整包路径，例如：
   export RLINF_EXT_MODULE=workflows.scripts.rlinf_ext

独立运行的检查点转换等工具（例如
``python -m rlinf.utils.ckpt_convertor.fsdp_convertor.convert_pt_to_hf``）在调用
``get_model`` 之前也会加载 ``RLINF_EXT_MODULE``，与 Worker 侧行为一致；因此若
``model_type`` 仅通过扩展模块注册，转换前同样需要设置该环境变量。

2. 模型实现
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

在 `rlinf/models/embodiment/your_model_action_model.py` 中创建你的类，并继承自 HuggingFace 基类。  
对于接入 RLinf 的自定义 VLA 模型，需要遵循 `rlinf.models.embodiment.base_policy.BasePolicy`
的接口约定，至少提供 `forward` 和 `predict_action_batch` 接口；如果直接继承
`BasePolicy`，通常需要实现 `default_forward` 和 `predict_action_batch`，其中 `forward`
会由基类统一分发。`predict_action_batch` 用于封装生成、解码和可选的数值计算，将
RL 逻辑保持在模型内部。  

.. code-block:: python

  from typing import Any

  from rlinf.models.embodiment.base_policy import BasePolicy

  class YourModelForRLActionPrediction(BasePolicy):
      def default_forward(
          self,
          forward_inputs: dict[str, Any],
          **kwargs,
      ) -> dict[str, Any]:
          return {
              "logprobs": ...,  # [B, ...]
              "values": ...,    # [B] or [B, 1]
              "entropy": ...,   # [B] or [B, 1]
          }

      def predict_action_batch(
          self,
          env_obs: dict[str, Any],
          mode: str = "train",
          compute_values: bool = True,
          **kwargs,
      ) -> tuple[Any, dict[str, Any]]:
          actions = ...  # [B, action_chunk, action_dim] or flattened env action
          result = {
              "prev_logprobs": ...,
              "prev_values": ...,
              "forward_inputs": {
                  "chains": ...,
                  "denoise_inds": ...,
                  "action": ...,
                  "model_action": ...,
              },
          }
          return actions, result

参考 `rlinf/models/embodiment/openpi/tasks/rl.py`，这三个接口的输入输出建议按下面理解：

- ``forward(forward_type=..., **kwargs)``:
  统一分发入口，根据 ``forward_type`` 路由到 ``default_forward``、``sft_forward``、
  ``sac_forward`` 或其他训练分支。对于自定义 VLA 模型，推荐保留这一层分发，
  让 rollout、actor、sft 等调用方都走统一入口。
- ``default_forward(forward_inputs, **kwargs)``:
  用于训练阶段根据 rollout 缓存的中间结果重新计算 logprob / value / entropy。
  参考 OpenPI，``forward_inputs`` 通常至少包含：

  - ``chains``: 扩散或迭代采样过程中的动作链，供训练时重算 logprob 使用。
  - ``denoise_inds``: 每个样本对应的去噪 step 索引，决定取哪一步的训练信号。
  - ``tokenized_prompt`` / ``tokenized_prompt_mask``: 文本 prompt 及其 mask。
  - ``action``: 实际交给环境执行的动作，通常展平成 ``[B, ...]``。
  - ``model_action``: 模型原始输出动作，通常在输出变换前保留。
  - 观测字段: 如 ``observation/image``、``observation/state``、
    ``observation/wrist_image`` 等，供模型重新构造 observation。

  OpenPI 的 ``default_forward`` 返回一个 ``dict``，核心字段包括：

  - ``logprobs``: 当前动作在训练分支下重算得到的对数概率。
  - ``values``: value head 输出的状态值。
  - ``entropy``: 策略熵或等价的不确定性统计，用于 PPO / RL loss。
- ``predict_action_batch(env_obs, mode="train"|"eval", compute_values=True, **kwargs)``:
  用于 rollout / 推理阶段，输入环境观测并输出可直接执行的动作。参考 OpenPI，
  ``env_obs`` 通常包含：

  - ``main_images``: 主视角图像。
  - ``wrist_images``: wrist camera 图像，可选。
  - ``extra_view_images``: 额外视角图像，可选。
  - ``states``: 低维状态。
  - ``task_descriptions``: 文本任务描述。

  OpenPI 的返回值是 ``(actions, result)``：

  - ``actions``: 直接发送给环境执行的动作张量。
  - ``result["prev_logprobs"]``: rollout 时记录下来的旧策略 logprob。
  - ``result["prev_values"]``: rollout 时记录下来的旧 value。
  - ``result["forward_inputs"]``: 训练阶段会再次送入 ``default_forward`` 的缓存字段集合。

实现自定义模型时，不要求字段名与 OpenPI 完全一致，但建议保证两点：一是
``predict_action_batch`` 返回的 ``forward_inputs`` 足以让 ``default_forward``
重建训练所需的全部信息；二是 ``default_forward`` 输出至少覆盖训练算法实际依赖的
``logprobs``、``values``、``entropy`` 等字段。

3. 配置文件
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

在 `examples/embodiment/config/your_config.yaml` 中创建配置文件，  
包含 `model_type`、`action_token_len` 和 `precision` 等字段。  
该模板会暴露你模型的超参数，方便实验设置。  

.. code-block:: yaml

  model:
    model_type: "your_model_type"
    action_token_len: 7
    action_chunks_len: 1
    unnorm_key: your_action_key
    precision: "bf16"
    vocab_size: 32000
    hidden_size: 4096
    image_size: [224, 224]
    is_lora: False
    low_cpu_mem_usage: True
    trust_remote_code: True

如果你的自定义模型在 FSDP 下需要显式指定 wrapping 规则，也可以在配置中补充
``fsdp_config.wrap_policy``。当该字段中出现自定义规则时，RLinf 会优先使用这里的
配置；否则仍按模型自身的 ``_no_split_modules`` / ``_no_split_names`` 以及内置逻辑
处理。

常用字段包括：

- ``transformer_layer_cls_to_wrap``: 按类名指定需要按 transformer block 方式 wrapping
  的模块，适合 decoder layer、attention block 等主体结构。
- ``module_classes_to_wrap``: 按类名指定额外需要 wrapping 的模块，适合 vision encoder、
  projector、adapter 等非标准 transformer block。
- ``no_split_names``: 按模块上的 ``_fsdp_wrap_name`` 做更细粒度的 wrapping，适合类名
  不方便区分、但模块角色固定的场景。

.. code-block:: yaml

  fsdp_config:
    wrap_policy:
      transformer_layer_cls_to_wrap:
        - "MyDecoderLayer"
      module_classes_to_wrap:
        - "MyVisionTower"
        - "MyProjector"
      no_split_names:
        - "value_head"

如果你的自定义模块本质上就是主干 transformer block，通常只配置
``transformer_layer_cls_to_wrap`` 就够了；``module_classes_to_wrap`` 更适合补充那些
不属于主干 block、但仍希望单独参与 FSDP wrapping 的模块。

4. 模型使用
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

完成 ``register_model("your_model_type", build_my_model, category="embodied")`` 后，
即可在 YAML 配置中直接使用 ``model_type: your_model_type``。如果你的模型还依赖
对应的 ``processor`` 类，建议在 ``build_my_model`` 中统一完成加载后再返回模型实例。

.. code-block:: python

  from omegaconf import OmegaConf
  from rlinf.models import get_model

  cfg = OmegaConf.create(
      {
          "model_type": "your_model_type",
          "precision": "fp32",
          "is_lora": False,
      }
  )
  model = get_model(cfg)

5. 注意事项
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

- RLinf 会在环境侧对不同模型输出的 action 做额外处理，例如
  `rlinf/envs/action_utils.py` 中的 `prepare_actions(...)` 会根据 `env_type`
  和 `model_type` 执行不同的后处理逻辑。如果你使用的是全新的自定义 `model_type`，
  建议直接在 `predict_action_batch(...)` 中完成这部分额外的 action 后处理，
  让返回给环境的 `actions` 已经是最终可执行格式，这样可以避免再为新模型类型补充
  额外的环境侧分支逻辑。
- 使用 `register_model(...)` 注册自定义模型时，可以通过 `force=True` 覆盖已有模型实现。
  这种方式适合“替换 RLinf 内置模型实现但沿用原有 model type”的场景。这样你可以继续复用
  RLinf 针对该内置 `model_type` 已有的 action 处理、训练分支和其他兼容逻辑，从而减少
  额外适配代码；前提是你的模型接口需要与 RLinf 内置模型保持完全对齐。
- 对于不同 VLA 模型，RLinf 在 FSDP 训练下使用了不同的 wrap policy，相关逻辑可参考
  `rlinf/hybrid_engines/fsdp/utils.py` 中的 `get_fsdp_wrap_policy(...)`。如果你接入的是
  自定义模型，建议在模型配置中显式补充对应的 wrap policy 配置，确保 transformer layer、
  vision encoder、projector、value head 等关键模块按预期参与 FSDP wrapping；否则可能
  出现训练性能下降、显存不合理或某些模块未被正确切分的问题。


按 Wrapper 设置混合精度（FSDP1）
----------------------------------

``mixed_precision`` 是全局默认 MP 策略。在 ``wrappers`` 中选择模块，
在 ``mixed_precision_policies`` 中定义 MP 策略，用 ``mixed_precision_rules``
将两者的名称配对，覆盖对应 wrapper 的全局默认策略。下面的 Pi05 示例让
精度敏感模块使用 FP32，其他部分使用 BF16：

OpenPI 设置 ``actor.model.precision: fp32``，让原始参数使用 FP32；
设置 ``actor.model.openpi.embed_dtype: bf16``，让主干激活和残差使用 BF16。

.. code-block:: yaml

   fsdp_config:
     strategy: fsdp
     sharding_strategy: no_shard
     use_orig_params: true
     mixed_precision:
       param_dtype: bf16
       reduce_dtype: fp32
       buffer_dtype: fp32
       cast_forward_inputs: false
       cast_root_forward_inputs: false
     wrappers:
       projections:
         wrap_names: [action_in_proj, action_out_proj, time_mlp_in, time_mlp_out]
       norms:
         module_classes: [RMSNorm]
       vision_embedding:
         module_names: [img, img.stem]
       vision_mlps:
         module_names: ["img.encoder.layers.*.mlp"]
         wrap_mode: subtree
     mixed_precision_policies:
       fp32:
         param_dtype: fp32
         reduce_dtype: fp32
         buffer_dtype: fp32
         cast_forward_inputs: true
       fp32_preserve_inputs:
         param_dtype: fp32
         reduce_dtype: fp32
         buffer_dtype: fp32
         cast_forward_inputs: false
     mixed_precision_rules:
       projections: fp32
       norms: fp32_preserve_inputs
       vision_embedding: fp32_preserve_inputs
       vision_mlps: fp32
     amp_autocast:
       enabled: false

每个 wrapper 选择一种匹配方式：``module_names`` 支持完整模块路径和
``img.encoder.layers.*.mlp`` 等 glob；``module_classes`` 支持短类名和完整限定名，
与 ``wrap_policy.module_classes_to_wrap`` 共用解析规则；
``wrap_names`` 匹配已有的 ``_fsdp_wrap_name`` 标签。Pi05 在模型初始化时
为 projection 模块设置这些标签。

通过 ``wrap_mode`` 控制包装边界：

- ``individual`` （默认）：每个命中模块分别包装，保留自动子包装。
- ``subtree``：每个命中模块的完整子树分别包装，内部不再创建 wrapper。
  本例为每层 MLP 创建一个 FP32 wrapper。
- ``combined``：将所有命中模块合到现有共同父模块，内部不再创建 wrapper；
  需要选中该父模块下的所有参数和 buffer。

每个 wrapper 管理的参数必须具有一致的原始 dtype，混合 ``requires_grad``
需要设置 ``use_orig_params: true``。subtree 和 combined 边界不能与其他
显式选择的 wrapper 重叠。

命名策略必须填写三个 dtype 字段。未绑定规则的 wrapper 使用全局策略，
嵌套 wrapper 保留各自策略。全局和命名策略的 ``cast_forward_inputs`` 默认均为
``true``。模块自行处理输入转换时，例如 OpenPI RMSNorm，将其设为 ``false``。输入需要保留 FP32 精度时，例如 Pi05 的 action 和
timestep，将全局 ``cast_root_forward_inputs`` 设为 ``false``，避免输入到达
该 wrapper 前已被舍入到 BF16。

``buffer_dtype`` 控制浮点 buffer 的计算 dtype。FSDP 在完整和分片模型
checkpoint 中按原始 dtype 保存 buffer；``LOCAL_STATE_DICT`` 不做该 dtype 恢复。
``summon_full_params()`` 恢复参数精度，不恢复 buffer 精度。

保留低精度梯度
~~~~~~~~~~~~~~~~

全局策略和命名策略中的 ``keep_low_precision_grads`` 默认均为 ``false``。
FSDP 将梯度转回参数的原始 dtype，供优化器更新。设为 ``true`` 时，分片策略和
FSDP CPU 参数 offload 使用计算 dtype 准备梯度（``param_dtype``，未设置时为原始 dtype）；
不使用 CPU offload 的 ``no_shard`` 保留实际归约 dtype。保留较小的 dtype 可以减少梯度存储。

使用 FSDP1 的 ``no_shard`` 和 ``FP32MasterAdamW``，可以用保留的不同 dtype
梯度更新参数。为整个 actor 选择该优化器：

.. code-block:: yaml

   actor:
     model:
       precision: fp32
     optim:
       use_fp32_master_params: true
     fsdp_config:
       strategy: fsdp
       sharding_strategy: no_shard
       mixed_precision:
         param_dtype: bf16
         reduce_dtype: bf16
         buffer_dtype: fp32
         keep_low_precision_grads: true

在 ``mixed_precision_policies`` 中设置 ``keep_low_precision_grads``，可以为指定
wrapper 保留梯度。优化器沿用参数分组和优化器配置，在更新时将梯度转为 FP32，
并保持 FP32 优化器状态。原始 BF16/FP16 参数还会有一份 FP32 master weights。
使用原生 AdamW 时，保持默认的 ``keep_low_precision_grads: false``。
