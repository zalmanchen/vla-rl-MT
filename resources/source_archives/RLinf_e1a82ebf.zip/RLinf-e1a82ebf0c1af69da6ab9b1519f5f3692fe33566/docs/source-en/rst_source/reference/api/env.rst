Environment Interface
======================

This section provides the key APIs of the **environment** in the RLinf framework,  
specifically designed for **embodied intelligence** scenarios.  
As an example, we demonstrate the env setup using LIBERO as the background.  
For any other simulator, the process is analogous.


EnvWorker
---------------

.. autoclass:: rlinf.workers.env.env_worker.EnvWorker
   :members: 
   :member-order: bysource

Environment
-----------------------

.. autoclass:: rlinf.envs.sim.libero.libero_env.LiberoEnv
   :members: 
   :member-order: bysource


