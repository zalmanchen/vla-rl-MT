Agentic Scenarios
=================

RLinf's worker abstraction, flexible communication modules, and support for various accelerators make it naturally suited for building agent workflows and training agents.
The following examples include math reasoning RL and agentic AI workflows, such as agent workflow construction, online RL training, environment integration, and **reasoning-centric agent training**.

.. raw:: html

   <div style="display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 20px; align-items: flex-start; justify-items: center; max-width: 980px; margin: 0 auto;">
     <div style="flex: 1 1 30%; max-width: 300px; text-align: center;">
       <a href="wideseek_r1/index.html" style="display: block;"><img src="https://raw.githubusercontent.com/RLinf/misc/main/pic/wideseek_r1/scaling.png"
            style="width: 100%; height: 200px; object-fit: contain; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.15);" /></a>
       <p style="margin-top: 8px; font-size: 14px; line-height: 1.4;">
        <a href="wideseek_r1/index.html" style="text-decoration: underline; color: blue;">
          <b>WideSeek-R1</b>
         </a><br>
         Exploring Width Scaling for Broad Information Seeking via Multi-Agent Reinforcement Learning
       </p>
     </div>

     <div style="flex: 1 1 30%; max-width: 300px; text-align: center;">
       <a href="agentlightning_calc_x.html" style="display: block;"><img src="https://raw.githubusercontent.com/RLinf/misc/main/pic/agentlightning_calcx.png"
            style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.15);" /></a>
       <p style="margin-top: 8px; font-size: 14px; line-height: 1.4;">
        <a href="agentlightning_calc_x.html" style="text-decoration: underline; color: blue;">
          <b>AgentLightning Calc-X</b>
         </a><br>
         Agent Lightning orchestrates agent RL; RLinf serves as the distributed training backend
       </p>
     </div>

     <div style="flex: 1 1 30%; max-width: 300px; text-align: center;">
       <a href="coding_online_rl.html" style="display: block;"><img src="https://raw.githubusercontent.com/RLinf/misc/main/pic/coding_online_rl_offline_numbers.jpg"
            style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.15);" /></a>
       <p style="margin-top: 8px; font-size: 14px; line-height: 1.4;">
        <a href="coding_online_rl.html" style="text-decoration: underline; color: blue;">
          <b>Open-Source Online RL for Code Completion</b>
         </a><br>
         End-to-end online RL with RLinf + Continue, improving model performance by 52%
       </p>
     </div>

     <div style="flex: 1 1 30%; max-width: 300px; text-align: center;">
       <a href="searchr1/index.html" style="display: block;"><img src="https://raw.githubusercontent.com/RLinf/misc/main/pic/searchr1.png"
            style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.15);" /></a>
       <p style="margin-top: 8px; font-size: 14px; line-height: 1.4;">
        <a href="searchr1/index.html" style="text-decoration: underline; color: blue;">
          <b>Search-R1 RL Training</b>
         </a><br>
         Train LLMs to answer questions by invoking search tools, RLinf accelerates the training process by 55%.
       </p>
     </div>

     <div style="flex: 1 1 30%; max-width: 300px; text-align: center;">
       <a href="rstar2.html" style="display: block;"><img src="https://raw.githubusercontent.com/RLinf/misc/main/pic/rstar2-RLinf-7b.jpg"
            style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.15);" /></a>
       <p style="margin-top: 8px; font-size: 14px; line-height: 1.4;">
        <a href="rstar2.html" style="text-decoration: underline; color: blue;">
          <b>rStar2-agent RL Training</b>
         </a><br>
         Enabling models to autonomously reason and reflect using Python tools through reinforcement learning, achieving frontier-level mathematical reasoning at extremely low computational cost
       </p>
     </div>

     <div style="flex: 1 1 30%; max-width: 300px; text-align: center;">
       <img src="https://raw.githubusercontent.com/RLinf/misc/main/pic/waiting_icon.jpg"
            style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.15);" />
       <p style="margin-top: 8px; font-size: 14px; line-height: 1.4;">
         <b>[Ongoing]SWE-agent</b><br>
         Unified deployment, inference, and training with high flexibility and performance
       </p>
     </div>

     <div style="flex: 1 1 30%; max-width: 300px; text-align: center;">
       <a href="math_reasoning/index.html" style="display: block;"><img src="https://raw.githubusercontent.com/RLinf/misc/main/pic/math_numbers_small.jpg"
            style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.15);" /></a>
       <p style="margin-top: 8px; font-size: 14px; line-height: 1.4;">
        <a href="math_reasoning/index.html" style="text-decoration: underline; color: blue;">
          <b>Math Reasoning</b>
         </a><br>
         GRPO and PPO training for math reasoning with Qwen2.5 and Moonlight-16B
       </p>
     </div>

     <div style="flex: 1 1 30%; max-width: 300px; text-align: center;">
       <a href="qwen3_vl_geo3k.html" style="display: block;"><img src="https://github.com/RLinf/misc/raw/main/pic/geo_problem.png"
            style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.15);" /></a>
       <p style="margin-top: 8px; font-size: 14px; line-height: 1.4;">
        <a href="qwen3_vl_geo3k.html" style="text-decoration: underline; color: blue;">
          <b>Qwen3-VL GRPO for VQA</b>
         </a><br>
         GRPO training for vision-language reasoning on geometric problem solving (Geo3K)
       </p>
     </div>

   </div>

.. toctree::
   :hidden:
   :maxdepth: 2

   WideSeek-R1 <wideseek_r1/index>
   AgentLightning <agentlightning_calc_x>
   Coding Online RL <coding_online_rl>
   Search-R1 <searchr1/index>
   rStar2 <rstar2>
   Math Reasoning <math_reasoning/index>
   Qwen3 VL GRPO <qwen3_vl_geo3k>
