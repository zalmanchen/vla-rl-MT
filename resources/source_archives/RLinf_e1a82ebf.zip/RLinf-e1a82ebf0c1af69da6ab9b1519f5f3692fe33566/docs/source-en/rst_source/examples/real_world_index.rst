RL with Real-World Robots
=========================

Use this section when your starting point is physical robot hardware. Start with Franka if you use a Franka arm or a Franka-based rig; use the other robot pages for YAM, GimArm, XSquare Turtle2, Dexmal DOS-W1, AgileX Piper, and SO101.

Choose a guide for hardware checks, teleoperation, data collection, sim-to-real transfer, deployment, or online RL.

.. raw:: html

   <div style="display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 20px; align-items: flex-start; justify-items: center; max-width: 980px; margin: 0 auto;">

     <div style="flex: 1 1 30%; max-width: 300px; text-align: center;">
       <a href="embodied/franka_index.html" style="display: block;"><img src="https://raw.githubusercontent.com/RLinf/misc/main/pic/franka_arm_small.jpg"
            style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.15);" /></a>
       <p style="margin-top: 8px; font-size: 14px; line-height: 1.4;">
         <a href="embodied/franka_index.html" style="text-decoration: underline; color: blue;">
           <b>Single-Arm Franka</b>
         </a><br>
         Use the single-arm Franka section for real-world RL, reward models, data collection, dexterous hands, SFT, and deployment
       </p>
     </div>
     <div style="flex: 1 1 30%; max-width: 300px; text-align: center;">
       <a href="embodied/dual_franka_index.html" style="display: block;"><img src="https://raw.githubusercontent.com/RLinf/misc/main/pic/dual-franka.jpg"
            style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.15);" /></a>
       <p style="margin-top: 8px; font-size: 14px; line-height: 1.4;">
         <a href="embodied/dual_franka_index.html" style="text-decoration: underline; color: blue;">
           <b>Dual-Arm Franka</b>
         </a><br>
         Use the dual-arm Franka section for collection, SFT, deployment, and PICO-assisted HG-DAgger
       </p>
     </div>
     <div style="flex: 1 1 30%; max-width: 300px; text-align: center;">
       <a href="embodied/gim_arm.html" style="display: block;"><img src="https://raw.githubusercontent.com/RLinf/misc/main/pic/gim-arm.png"
            style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.15);" /></a>
       <p style="margin-top: 8px; font-size: 14px; line-height: 1.4;">
         <a href="embodied/gim_arm.html" style="text-decoration: underline; color: blue;">
           <b>GimArm</b>
         </a><br>
         Train a 6-DOF GimArm peg-insertion task over SocketCAN with Pinocchio-based FK
       </p>
     </div>
     <div style="flex: 1 1 30%; max-width: 300px; text-align: center;">
       <a href="embodied/xsquare_turtle2.html" style="display: block;"><img src="https://raw.githubusercontent.com/RLinf/misc/main/pic/xsquare_turtle2_arm_small.jpg"
            style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.15);" /></a>
       <p style="margin-top: 8px; font-size: 14px; line-height: 1.4;">
         <a href="embodied/xsquare_turtle2.html" style="text-decoration: underline; color: blue;">
           <b>XSquare Turtle2</b>
         </a><br>
         Run SAC with a CNN policy on the XSquare Turtle2 dual-arm robot
       </p>
     </div>
     <div style="flex: 1 1 30%; max-width: 300px; text-align: center;">
       <a href="embodied/dosw1.html" style="display: block;"><img src="https://raw.githubusercontent.com/RLinf/misc/main/pic/dos-w1.png"
            style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.15);" /></a>
       <p style="margin-top: 8px; font-size: 14px; line-height: 1.4;">
         <a href="embodied/dosw1.html" style="text-decoration: underline; color: blue;">
           <b>Dexmal DOS-W1</b>
         </a><br>
         Train a flow-matching + SAC pick task on the Dexmal DOS-W1 dual-arm robot
       </p>
     </div>

   </div>

YAM
---

Use :doc:`the YAM section <embodied/yam_index>` for dual-arm setup and data collection guides.

Piper and SO101 Setup
---------------------

Use these guides to connect an arm and run its hardware test script. Piper and SO101 do not yet have supported real-world tasks or training workflows.

.. grid:: 1 2 2 2
   :gutter: 2

   .. grid-item-card:: AgileX Piper
      :link: embodied/piper
      :link-type: doc

      Configure CAN and run the Piper joint and gripper test script.

   .. grid-item-card:: SO101
      :link: embodied/so101
      :link-type: doc

      Set up motors, calibrate an SO-101, and run the joint and gripper test script.

.. toctree::
   :hidden:
   :maxdepth: 3

   Single-Arm Franka <embodied/franka_index>
   Dual-Arm Franka <embodied/dual_franka_index>
   YAM <embodied/yam_index>
   GimArm <embodied/gim_arm>
   XSquare Turtle2 <embodied/xsquare_turtle2>
   DOS-W1 <embodied/dosw1>
   Piper <embodied/piper>
   SO101 <embodied/so101>
